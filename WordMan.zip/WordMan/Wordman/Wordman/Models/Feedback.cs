﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Wordman.Models
{
    public class Feedback
    {
        [StringLength(maximumLength: 500)]
        [Required(ErrorMessage = "Message must not be empty")]

        public string Feedback1 { get; set; }
        public int FeedBackId { get; set; }
        [Required]
        public string Name { get; set; }
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address.")]
        [Required(ErrorMessage = "EmailId is mandatory.")]
        
        public string Emailid { get; set; }
    }
}
