﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;

namespace Wordman.Models
{
    public class Users
    { 
       
        public int UserId { get; set; }
        [Required(ErrorMessage = "UserName Required")]
        [StringLength(maximumLength: 20)]
        [Remote("IsAlreadySigned", "Home", HttpMethod = "POST", ErrorMessage = "UserName already Exist")]
        [RegularExpression("^(?!\\s*$)[-a-zA-Z0-9_:,.' ']{1,100}$", ErrorMessage = "Enter valid username")]
        public string UserName { get; set; }
        [RegularExpression("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$", ErrorMessage = " Password must be at least 6 characters, " +
            "and must include at least one upper case letter, one lower case letter, and one numeric digit.")]
        
        [Required(ErrorMessage = "Password is mandatory.")]
        [DisplayName("User password")]
        public string UserPassword { get; set; }
        public byte? RoleId { get; set; }
        [Required(ErrorMessage = "Gender is mandatory.")]
        [RegularExpression("M|F", ErrorMessage = "Gender should be M or F")]
        public string Gender { get; set; }
        //  [Required]
        [Required(ErrorMessage = "DOB is mandatory.")]
        [Remote("ValidateDate", "Home", HttpMethod = "POST", ErrorMessage = "Invalid Date of Birth")]
 
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:mm/dd/yyyy}")]
     
        [DisplayName("Date of birth")]

        
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Address is mandatory.")]
        [RegularExpression("^(?!\\s*$)[-a-zA-Z0-9_:,.' ']{1,100}$",ErrorMessage="Enter valid address")]


        public string Address { get; set; }
        public decimal? CardNumber { get; set; }
        // [Required]
        
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address.")]
        [Required(ErrorMessage = "EmailId is mandatory.")]
        [DisplayName("Email Id")]
        [Remote("CheckEmailId", "Home", HttpMethod = "POST", ErrorMessage = "Email Id Already Exists")]

        public string EmailId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? PaymentStatus { get; set; }
    }
    
        
    }

