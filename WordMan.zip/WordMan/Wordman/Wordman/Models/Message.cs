﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Wordman.Models
{
    public class Message
    {
        public string MessageId { get; set; }
        [StringLength(maximumLength: 500)]
        [Required(ErrorMessage = "Message must not be empty")]
        [RegularExpression("^(\\s)[-a-zA-Z.' ']{1,100}$", ErrorMessage = "Enter Valid Message")]

        public string MessageDetails { get; set; }
        [Required]
        [Range(1, 1000, ErrorMessage = "id Must be between  0 to 1000")]
        [Remote("IscategoryAvailable", "Admin", HttpMethod = "POST", ErrorMessage = "InvalidCategory")]


        public byte? CategoryId { get; set; }
        public int? Download { get; set; }
        [Required]
        public string Relationship { get; set; }
        public double Rate { get; set; }
        public int? RatingCount { get; set; }
    }
}
