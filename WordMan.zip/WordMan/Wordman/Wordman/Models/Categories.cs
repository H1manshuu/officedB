﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Wordman.Models
{
    public class Categories
    {
       
        public byte CategoryId { get; set; }
        [Required]
        [RegularExpression("^(?!\\s*$)[-a-zA-Z.' ']{1,100}$", ErrorMessage = "Enter valid category")]

        public string CategoryName { get; set; }
    }
}
