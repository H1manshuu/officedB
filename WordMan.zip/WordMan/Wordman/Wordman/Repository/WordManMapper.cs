﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.WordMan.DataAccessLayer.Models;
namespace Wordman.Repository
{
    public class WordmanMapper: Profile
    {
        public WordmanMapper()
        {	 CreateMap<Otp, Models.Otp>();
            CreateMap<Models.Otp, Otp>();
           
            CreateMap<FeedBack, Models.Feedback>();
            CreateMap<Models.Feedback, FeedBack>();
            CreateMap<Categories, Models.Categories>();
            CreateMap<Message,Models.Message>();
            CreateMap<Models.Categories,Categories>();
            CreateMap<Models.Message,Message>();
            CreateMap<Models.Users,Users>();
            CreateMap<Users, Models.Users>();
            CreateMap<Models.Rating,Rating>();
            CreateMap<Rating, Models.Rating>();
            CreateMap<Models.CardDetails, CardDetails>();
            CreateMap<CardDetails, Models.CardDetails>();
        }
    }
}
