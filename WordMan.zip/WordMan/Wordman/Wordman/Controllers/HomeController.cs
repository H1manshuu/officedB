﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Wordman.Models;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using System.Net;
using System.Net.Mail;

namespace Wordman.Controllers
{
    public class HomeController : Controller  /*MAPPER*/
    {
        private readonly IMapper _mapper;
        private readonly  WordManRepository  _repObj;
        public HomeController(WordManRepository repObj,IMapper mapper)
        {
            _mapper = mapper;
            _repObj = repObj;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Checkrole(IFormCollection frm)  /*CHECKROLE */

        {
           
                string userId = frm["uname"];
                string password = frm["psw"];
                string checkbox = frm["remember"];
                if (checkbox == "on")
                {
                    CookieOptions option = new CookieOptions();
                    option.Expires = DateTime.Now.AddDays(2);
                    Response.Cookies.Append("Username", userId, option);
                    Response.Cookies.Append("Password", password, option);
                }
            try
            {
                byte? roleId = _repObj.ValidateCredentials(userId, password);
                HttpContext.Session.SetString("roleid", Convert.ToString(roleId));


                if (roleId == 1)
                {
                    HttpContext.Session.SetString("usr", userId);
                    return RedirectToAction("AdminHome", "Admin");
                }
                 if (roleId == 2)
                {
                    HttpContext.Session.SetString("usr", userId);
                    return RedirectToAction("UserHome", "User");
                }

                if (roleId==8)
                {
                    TempData["abc"] = "enter correct password";
                    return RedirectToAction("UserHome1", "User");

                }
                if (roleId == 9)
                {
                    TempData["abc"] = "no user found";
                    return RedirectToAction("UserHome1", "User");

                }

                if (roleId == 7)
                {
                    HttpContext.Session.SetString("paymentuser",userId);
                    TempData["abc"] = "Payment Pending!!Pay First";
                    return RedirectToAction("UserHome1", "User");

                }


                return View("ErrorLogin");
            }
            catch (Exception e)
            {
                return View("ErrorLogin");
            }
        }
           

        
        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()  /* ERROR VIEW */
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Logout()  
        {
            HttpContext.Session.Remove("usr"); ;
            return RedirectToAction("UserHome", "User");
        }
        public IActionResult About()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult Contact()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult FeedBack()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult FeedBackNew()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }

        public IActionResult RegisterUser()
        {
            return View();
        }
        public IActionResult SaveRegisterUser(Models.Users usr)  /*SAVE REGISTERED USER FUNCTION */
        {
            bool status = false;
          //  if (ModelState.IsValid)
          //  {

                try
                {
                    status = _repObj.RegisterUser(_mapper.Map<Infosys.WordMan.DataAccessLayer.Models.Users>(usr));
                if (status)
                {
                    TempData["saved"] = "saved";
                        return RedirectToAction("PaymentPortal", "User");
                     }
                    else
                        return View("ErrorRegister");
                }
                catch (Exception)
                {
                    return View("ErrorRegister");
                }
            //}
            //else
            //    return View();

        }
        public IActionResult SaveFeedBack(Models.Feedback fb)  /*SAVE FEEDBACK FUNCTION */
        {
            bool status = false;
            try
            {
                status = _repObj.AddFeedBack(_mapper.Map<FeedBack>(fb));
                if (status)
                {
                    TempData["a"] = "FeedBack Submitted";

                    System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient("10.122.13.10");

                    client.UseDefaultCredentials = false;

                    client.Credentials = new NetworkCredential("Trainee_T2@myssmtp.com", "infy@123");



                    MailMessage mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress("Trainee_T2@myssmtp.com");

                    mailMessage.To.Add(fb.Emailid);
                    //String str = "﻿﻿﻿<b>Team WordMan</b>";

                    mailMessage.Body = "Thank you for your FeedBack!! Please visit us again!!!-Regards:Team WordMan";

                    mailMessage.Subject = "FeedBack";

                    client.Send(mailMessage);











                    return RedirectToAction("FeedBackNew", "Home");
                }
                else
                {
                    TempData["a"] = "Some Error Occured";
                    return RedirectToAction("FeedBackNew", "Home");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
           
        }

        //CheckEmailId
    [HttpPost]
        public JsonResult CheckEmailId(string emailId)
        {

            return Json(_repObj.IsEmailAvailable(emailId));

        }




        [HttpPost]
        public JsonResult IsAlreadySigned(string username)
        {

            return Json(_repObj.IsUserAvailable(username));

        }
        public void getratings(IFormCollection frm)
        {
            string userId = frm["ratings"];
            

        }
        [HttpPost]
        public JsonResult ValidateDate(DateTime DateOfBirth)
        {
           
          bool  status = false;
            if (DateOfBirth.Date <DateTime.Now.Date)
                status= true;
            return Json(status);

        }
		  public IActionResult ForgotPassword()
        {
            return RedirectToAction("ForgotPassword", "User");
        }

    }
}
