﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using AutoMapper;
using Infosys.WordMan.DataAccessLayer;
using Infosys.WordMan.DataAccessLayer.Models;
using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MimeKit;
using static System.Net.Mime.MediaTypeNames;

namespace Wordman.Controllers
{
    public class UserController : Controller
    {
        private readonly IMapper _mapper;
        private readonly WordManRepository _repObj;
        public UserController(WordManRepository repObj, IMapper mapper)
        {
            _repObj = repObj;
            _mapper = mapper;
        }
        public IActionResult UserHome()
        {
            _repObj.TrunkateOtp();
            var lstEntityProducts = _repObj.GetCategories();
            
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult UserHome1()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }

        public IActionResult ViewMessages(Models.Categories cat)
        {
            HttpContext.Session.Remove("searchstr");
            HttpContext.Session.SetString("rol", "1");
            ViewBag.CatName = cat.CategoryName;
            byte id = cat.CategoryId;
            var msglst = _repObj.GetMessageOnCategoryId(id);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(finalMsgList);

        }

        public IActionResult ViewCategory()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(lstModelProducts);
        }
        public IActionResult DeleteCateGory(Models.Categories cat)
        {
            bool status = false;
            try
            {
                status = _repObj.DeleteCategory(_mapper.Map<Categories>(cat));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }



        }
        public IActionResult SearchMessages(IFormCollection frm)
        {
            HttpContext.Session.SetString("rol", "2");

            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            string searchstring = frm["search"];
            HttpContext.Session.SetString("searchstr", searchstring);
            List<Models.Message> finalMsg = new List<Models.Message>();
            List<Message> msg = _repObj.SearchMessages(searchstring);
            foreach (var item in msg)
            {
                finalMsg.Add(_mapper.Map<Models.Message>(item));
            }
            return View(finalMsg);
        }

        public IActionResult GetTopRatedMessage()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;


            var lsttoprated = _repObj.TopRatedMessages();
            List<Models.Message> lstModelProduct = new List<Models.Message>();
            foreach (var product in lsttoprated)
            {
                lstModelProduct.Add(_mapper.Map<Models.Message>(product));
            }
            return View(lstModelProduct);

        }



        public IActionResult EditMessage(Models.Message msg)
        {   
            
                HttpContext.Session.SetString("cid2", Convert.ToString(msg.CategoryId));
            
            
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View(msg);
        }
        public IActionResult getrating(IFormCollection frm)

        {
            string rating = frm["ratings"];
            Models.Message msg = new Models.Message();
            msg.CategoryId = Convert.ToByte(frm["cid"]);
            msg.Download = Convert.ToInt32(frm["download"]);
            msg.MessageDetails = frm["md"];
            msg.Relationship = frm["relationship"];
            msg.MessageId = frm["mid"];
            msg.Rate = Convert.ToDouble(frm["rate"]);

            Models.Rating rat = new Models.Rating();
            rat.MessageId = frm["mid"];
            rat.UserId = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            rat.RatingValue = Convert.ToInt32(rating);
            var s = _repObj.GiveRating(_mapper.Map<Rating>(rat));
            _repObj.CalculateRating(_mapper.Map<Message>(msg));
            if (s == 1)
            {
                return RedirectToAction("EditMessage", msg);
            }
            else
            {
                return View("Error");
            }
        }
        public IActionResult IncrementDownload(IFormCollection frm)

        {

            Models.Message msg = new Models.Message();
            msg.CategoryId = Convert.ToByte(frm["cid"]);
            msg.Download = Convert.ToInt32(frm["download"]);
            msg.MessageDetails = frm["md"];
            msg.Relationship = frm["relationship"];
            msg.MessageId = frm["mid"];
            msg.Rate = Convert.ToDouble(frm["rate"]);
            msg.RatingCount = Convert.ToInt32(frm["ratingcount"]);
            var s = _repObj.IncDownload(_mapper.Map<Message>(msg));
            if (s)
            {
                return RedirectToAction("EditMessage", msg);
            }
            else
            {
                return View("Error");
            }
        }


        public IActionResult EditUser()
        {
            var uid = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            var usr = _repObj.getUserDetail(uid);
            ViewBag.user = usr.UserName;
            var finalusr = _mapper.Map<Models.Users>(usr);
            return View(finalusr);
        }
        public IActionResult EditUser1()
        {
            var uid = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            var usr = _repObj.getUserDetail(uid);
            ViewBag.user = usr.UserName;
            var finalusr = _mapper.Map<Models.Users>(usr);
            return View(finalusr);
        }
        public IActionResult SaveChangedPassword(IFormCollection obj)
        {
            bool status = false;
            try
            {
                var uid = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
                var usr = _repObj.getUserDetail(uid);
                string oldPassword = Convert.ToString(obj["oldpwd"]);
                string newPassword = Convert.ToString(obj["newpwd"]);
                string confirmPassword = Convert.ToString(obj["psw"]);

                if (usr.UserPassword == oldPassword)
                {
                    if (newPassword == confirmPassword)
                    {
                        status = _repObj.ChangePassword(newPassword, uid);
                        if (status)
                        {
                            TempData["password changed"] = "password changed!";
                            return RedirectToAction("Edited2", "User");
                        }
                        else
                            return View("Error");
                    }


                    else
                    {
                        TempData["password changed"] = "passwords don't match";
                        return RedirectToAction("Edited2", "User");
                    }
                }
                else
                    TempData["password changed"] = "Enter correct password";
                return RedirectToAction("Edited2", "User");



            }
            catch
            {
                return View("Error");
            }
        }

        public IActionResult Edited2()
        {
            var uid = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            var usr = _repObj.getUserDetail(uid);
            ViewBag.user = usr.UserName;
            var finalusr = _mapper.Map<Models.Users>(usr);

            return View(finalusr);

        }

        public IActionResult SaveEditedUser(Models.Users usr)
        {
            var uid = _repObj.GetUserId(HttpContext.Session.GetString("usr"));
            usr.UserId = uid;



            bool status = false;
            //  if (ModelState.IsValid)
            //  {

            try
            {
                status = _repObj.EditUserProfile(_mapper.Map<Infosys.WordMan.DataAccessLayer.Models.Users>(usr));
                if (status)
                {
                    TempData["msg"] = "data updated successfully";
                    return RedirectToAction("EditUser1", "User");
                }
                else
                {
                    TempData["msg"] = "some error occurred";
                    return RedirectToAction("EditUser1", "User");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
            //}
            //else
            //    return View();

        }
        public IActionResult SearchSaveFeedBack(IFormCollection frm)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            Models.Feedback msg = new Models.Feedback();

            msg.Emailid = frm["email"];
            msg.Name = frm["name"];
            msg.Feedback1 = frm["feedback"];
            bool status = false;
            try
            {
                status = _repObj.AddFeedBack(_mapper.Map<FeedBack>(msg));
                if (status)
                {
                    TempData["a"] = "FeedBack Submitted";
                    System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient("10.122.13.10");

                    client.UseDefaultCredentials = false;

                    client.Credentials = new NetworkCredential("Trainee_T2@myssmtp.com", "infy@123");



                    MailMessage mailMessage = new MailMessage();

                    mailMessage.From = new MailAddress("Trainee_T2@myssmtp.com");

                    mailMessage.To.Add(msg.Emailid);
                    //String str = "﻿﻿﻿<b>Team WordMan</b>";

                    mailMessage.Body = "Thank you for your FeedBack!! Please visit us again!!! " +
                        "-Regards:Team WordMan";

                    mailMessage.Subject = "FeedBack";

                    client.Send(mailMessage);



                    return View();
                }
                else
                {
                    TempData["a"] = "Some Error Occured";
                    return RedirectToAction("FeedBackNew", "Home");
                }
            }
            catch (Exception)
            {
                return View("Error");
            }

        }
        public IActionResult SortybyratingViewMsg(Models.Message mesg)
        { var catid = mesg.CategoryId;
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            var msglst = _repObj.GetMessageOnCategoryId((byte)catid);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            var msgrat = (from msg in finalMsgList orderby msg.Rate descending select msg).ToList();
            return View("ViewMessages", msgrat);
        }



        public IActionResult SortybyDownloadsViewMsg(Models.Message mesg)
        {
            var catid = mesg.CategoryId;
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            var msglst = _repObj.GetMessageOnCategoryId((byte)catid);
            List<Models.Message> finalMsgList = new List<Models.Message>();
            foreach (var product in msglst)
            {
                finalMsgList.Add(_mapper.Map<Models.Message>(product));
            }
            var msgrat = (from msg in finalMsgList orderby msg.Download descending select msg).ToList();
            return View("ViewMessages", msgrat);
        }




        public IActionResult SortbyratingSearch()
        {
            var searchstring = HttpContext.Session.GetString("searchstr");
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            List<Message> msg = _repObj.SearchMessages(searchstring);
            List<Models.Message> finalMsg = new List<Models.Message>();
            foreach (var item in msg)
            {
                finalMsg.Add(_mapper.Map<Models.Message>(item));
            }
            var srtlst = (from mesg in finalMsg orderby mesg.Rate descending select mesg).ToList();
            return View("SearchMessages", srtlst);
        }


        public IActionResult SortbyDownloadSearch()
        {
            var searchstring = HttpContext.Session.GetString("searchstr");
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            List<Message> msg = _repObj.SearchMessages(searchstring);
            List<Models.Message> finalMsg = new List<Models.Message>();
            foreach (var item in msg)
            {
                finalMsg.Add(_mapper.Map<Models.Message>(item));
            }
            var srtlst = (from mesg in finalMsg orderby mesg.Download descending select mesg).ToList();
            return View("SearchMessages", srtlst);
        }
        
        public IActionResult PaymentPortal()

        {
            if (TempData["saved"]==null)
            {
                Response.Redirect("https://localhost:44380/Home/RegisterUser");
            }
            return View();


        }
        public IActionResult PendingPayment()
        {
            TempData["saved"] = "saved";
            return RedirectToAction("PaymentPortal","User");

        }




        public IActionResult deleteuser()
        {
            bool status = false;
            if (HttpContext.Session.GetString("paymentuser")==null)
            {
                status = _repObj.DeleteLastUser();
                if (status)
                {
                    TempData["payment"] = "user deleted";
                    TempData["saved"] = "saved";
                }
                else
                {
                    TempData["payment"] = "user not deleted";
                    TempData["saved"] = "saved";

                }
                return RedirectToAction("PaymentPortal2", "User");
            }
            else
            {
                TempData["payment"] = "user not deleted";
                TempData["saved"] = "saved";
                HttpContext.Session.Remove("paymentuser");

                return RedirectToAction("PaymentPortal2", "User");
            }
           
          

        }


        
        public IActionResult PaymentPortal1()
        {
            if (TempData["saved"] == null)
            {
                TempData["payment"] = "";
                Response.Redirect("https://localhost:44380/Home/RegisterUser");
            }
            return View();


        }
        
        public IActionResult PaymentPortal2()
        {

            if (TempData["saved"] == null)
            {
                TempData["payment"] = "";
                Response.Redirect("https://localhost:44380/Home/RegisterUser");
            }
            TempData["payment"] = "user deleted";
            return View();


        }

        public IActionResult CheckAccount(IFormCollection obj)
        {
            int status = 0;
            
             Models.CardDetails card = new Models.CardDetails();
            card.CardNumber = Convert.ToDecimal(obj["cardnumber"]);
            card.CardType = Convert.ToString(obj["cardtype"]);
            card.Cvvnumber = Convert.ToInt32((obj["cvv"]));
            card.ExpiryDate = Convert.ToDateTime(obj["date"]);


            try
            {

                 status = _repObj.ValidateCardDetails
                    (_mapper.Map<Infosys.WordMan.DataAccessLayer.Models.CardDetails>(card));
                if (status == 1)
                {
                    if (HttpContext.Session.GetString("paymentuser")==null)
                    {
                        if (_repObj.validatepaymentstatus())
                        {
                            TempData["payment"] = "successfull";
                            TempData["saved"] = "saved";
                            return RedirectToAction("PaymentPortal1", User);
                        }
                        else
                        {
                            TempData["payment"] = "Some error occurred";
                            TempData["saved"] = "saved";
                            return RedirectToAction("PaymentPortal1", User);
                        }

                    }
                    else
                    {
                        String userId1 = HttpContext.Session.GetString("paymentuser");
                        if (_repObj.validatepaymentstatus_user(userId1))
                        {
                            TempData["payment"] = "successfull";
                            TempData["saved"] = "saved";
                            HttpContext.Session.Remove("paymentuser");

                            return RedirectToAction("PaymentPortal1", User);
                        }
                        else
                        {
                            TempData["payment"] = "Some error occurred";
                            TempData["saved"] = "saved";
                            HttpContext.Session.Remove("paymentuser");
                            return RedirectToAction("PaymentPortal1", User);
                        }

                    }




                }
                else if (status == -1) //no account found
                {
                    TempData["payment"] = "No Account Found";
                    TempData["saved"] = "saved";
                    return RedirectToAction("PaymentPortal1", User);
                }

                else if (status == -2) //insufficient balance
                {
                    TempData["payment"] = "Insufficient Balance";
                    TempData["saved"] = "saved";
                    return RedirectToAction("PaymentPortal1", User);
                }

                else if(status==-3) //credentials wrong
                {
                    TempData["payment"] = "Wrong Credentials";
                    TempData["saved"] = "saved";
                    return RedirectToAction("PaymentPortal1", User);
                }
                else //Some error Occured
                {
                    TempData["payment"] = "Some error occurred";
                    TempData["saved"] = "saved";
                    return RedirectToAction("PaymentPortal1", User);
                }


            }
            catch (Exception)
            {

                return View("Error");
            }



        }
		
        
  public IActionResult ForgotPassword()
        {
           
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        public IActionResult OtpGen(IFormCollection frm)
        {
            string email = frm["email"];
            string[] saAllowedCharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0","a","b","c","z","x","y","r","d","s","j" };
            HttpContext.Session.SetString("Otpemail",email);
            string OTP =  GenerateRandomOTP(6, saAllowedCharacters);
            var user = _repObj.GetUsersbyMail(email);
          


            if (user == null)
            {
                TempData["error"] = "Email does not Exist";

                return RedirectToAction("ForgotPassword");
            }
            HttpContext.Session.SetString("usname", user.UserName);

            System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient("10.122.13.10");

            client.UseDefaultCredentials = false;

            client.Credentials = new NetworkCredential("Trainee_T2@myssmtp.com", "infy@123");



            MailMessage mailMessage = new MailMessage();

            mailMessage.From = new MailAddress("Trainee_T2@myssmtp.com");

            mailMessage.To.Add(email);
            //String str = "﻿﻿﻿<b>Team WordMan</b>";
            
            mailMessage.Body = OTP.ToString() + " is your OTP to reset password.\nPlease do not share your password or OTP with anyone\nRegards Team WordMan https://localhost:44380/User/Forgotpassword2";

            mailMessage.Subject = "Password Reset";

            client.Send(mailMessage);








            DateTime expirytime = DateTime.Now;
            TimeSpan s = new TimeSpan(0, 2, 0);
            expirytime = expirytime + s;
            Models.Otp notp = new Models.Otp();
            notp.Email = email;
            notp.Expirytime = expirytime;
            notp.Otp1 = OTP;
            _repObj.AddOtp(_mapper.Map<Otp>(notp));
            otpviewer.Program a = new otpviewer.Program();

            a.Otpv(OTP);
            return RedirectToAction("Forgotpassword2");
        }
        public IActionResult ForgotPassword2()

        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();
        }
        private string GenerateRandomOTP(int iOTPLength, string[] saAllowedCharacters)

        {

            string sOTP = String.Empty;

            string sTempChars = String.Empty;

            Random rand = new Random();

            for (int i = 0; i < iOTPLength; i++)

            {

                int p = rand.Next(0, saAllowedCharacters.Length);

                sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];

                sOTP += sTempChars;

            }

            return sOTP;

        }
        public IActionResult ChangePasswordFinal(IFormCollection frm)
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            var em = HttpContext.Session.GetString("Otpemail");
            var o = _mapper.Map<Models.Otp>(_repObj.GetOtp(em));
            string userotp = frm["otpass"];
            if(o.Otp1.Equals(userotp) && o.Expirytime>=DateTime.Now)
            {
                return View();
            }
            else if(o.Expirytime<DateTime.Now)
                {
                _repObj.DeleteOtp(HttpContext.Session.GetString("Otpemail"));

                    TempData["Error2"] = "Invalid Otp";
                return RedirectToAction("ForgotPassword2");
            }
            else
            {
                TempData["Error2"] = "Invalid Otp";
                return RedirectToAction("ForgotPassword2");
            }
           
        }
        public IActionResult ChangePass(IFormCollection frm)
        {
            bool status = false;
            var uid = _repObj.GetUserId(HttpContext.Session.GetString("usname"));
            var usr = _repObj.getUserDetail(uid);

            string newPassword = Convert.ToString(frm["newpwd"]);
            string confirmPassword = Convert.ToString(frm["psw"]);



            if (newPassword == confirmPassword)
            {
                status = _repObj.ChangePassword(newPassword, uid);
                if (status)
                {
                    TempData["password Changed"] = "Your password successfully";
                    return RedirectToAction("ChangePasswordFinal2", "User");
                }
                else
                    return View("Error");
            }


            else
            {
                TempData["passwordNotChanged"] = "passwords don't match";
                return RedirectToAction("ChangePasswordFinal2", "User");
            }
        }

            public IActionResult ChangePasswordFinal2()
        {
            var lstEntityProducts = _repObj.GetCategories();
            List<Models.Categories> lstModelProducts = new List<Models.Categories>();
            foreach (var product in lstEntityProducts)
            {
                lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
            }
            ViewBag.anirudh = lstModelProducts;
            return View();

            }
        public IActionResult GoToHome()
        {
            _repObj.DeleteOtp(HttpContext.Session.GetString("Otpemail"));
            HttpContext.Session.Remove("Otpemail");
            HttpContext.Session.Remove("usname");
            


            return RedirectToAction("UserHome", "User");
        }

        public IActionResult BackToCategoryList()
        {
            if (HttpContext.Session.GetString("rol") == "1")
            {
                var categoryId = HttpContext.Session.GetString("cid2");

                var CategoryObject = _mapper.Map<Models.Categories>(_repObj.GetCategoryById(Convert.ToByte(categoryId)));
                HttpContext.Session.Remove("cid2");
                return RedirectToAction("ViewMessages", CategoryObject);
            }
            else
            {
                var searchstring = HttpContext.Session.GetString("searchstr");
                var lstEntityProducts = _repObj.GetCategories();
                List<Models.Categories> lstModelProducts = new List<Models.Categories>();
                foreach (var product in lstEntityProducts)
                {
                    lstModelProducts.Add(_mapper.Map<Models.Categories>(product));
                }
                ViewBag.anirudh = lstModelProducts;
                List<Message> msg = _repObj.SearchMessages(searchstring);
                List<Models.Message> finalMsg = new List<Models.Message>();
                foreach (var item in msg)
                {
                    finalMsg.Add(_mapper.Map<Models.Message>(item));
                }
                return View("SearchMessages",finalMsg);
            }
           
           }
                



    }

}
