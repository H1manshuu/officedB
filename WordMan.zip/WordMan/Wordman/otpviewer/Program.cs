﻿using System;

namespace otpviewer
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            while(true)
            {

            }
        }
        public void Otpv(string a)
        {
            Console.WriteLine("Otp:"+a);
        }
    }
}
