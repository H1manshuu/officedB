﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Categories
    {
        public Categories()
        {
            Templates = new HashSet<Templates>();
        }

        public byte CategoryId { get; set; }
        public string CategoryName { get; set; }

        public ICollection<Templates> Templates { get; set; }
    }
}
