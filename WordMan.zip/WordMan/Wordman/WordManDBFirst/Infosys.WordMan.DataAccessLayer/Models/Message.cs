﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Message
    {
        public Message()
        {
            Rating = new HashSet<Rating>();
        }

        public string MessageId { get; set; }
        public string MessageDetails { get; set; }
        public byte? CategoryId { get; set; }
        public int? Download { get; set; }
        public string Relationship { get; set; }
        public double? Rate { get; set; }
        public int? RatingCount { get; set; }

        public ICollection<Rating> Rating { get; set; }
    }
}
