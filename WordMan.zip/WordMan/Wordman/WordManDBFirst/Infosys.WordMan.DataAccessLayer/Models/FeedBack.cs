﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class FeedBack
    {
        public string Feedback1 { get; set; }
        public int FeedBackId { get; set; }
        public string Name { get; set; }
        public string Emailid { get; set; }
    }
}
