﻿using System;
using System.Collections.Generic;

namespace Infosys.WordMan.DataAccessLayer.Models
{
    public partial class Otp
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Otp1 { get; set; }
        public DateTime Expirytime { get; set; }
    }
}
